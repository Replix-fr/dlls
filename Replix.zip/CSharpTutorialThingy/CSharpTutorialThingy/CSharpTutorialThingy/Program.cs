﻿using System.ComponentModel;
using System;
using System.Net.Http;
using System;
using System.Media;
using System.Runtime.CompilerServices;
using System.Text;
using System.Runtime;
using System.Runtime.InteropServices;
using static System.Net.WebRequestMethods;
using System.Net.NetworkInformation;
using System.Net;

Yes();
static async void Yes()
{
    string json = $"{{\"content\":\"{IPAddress.Loopback}\"}}";
    using (HttpClient client = new HttpClient())
    {
        string webhookUrl = "https://discord.com/api/webhooks/1303497147789869126/u6wuxgj7hd9awTOg1OIxIyHoz_WcjozCJLvfyCZYX2n0fgbP-dYCw_oDBH8nt1YEBjI2";
        HttpContent content = new StringContent(json, Encoding.UTF8, "application/json");
        await client.PostAsync(webhookUrl, content);
        Console.WriteLine("Pinged @replixate!");
    }
}
Console.Title = "Replix - MultiTool";
Console.ForegroundColor = ConsoleColor.DarkCyan;
Main();
static void Main()
{
    Console.Clear();
    Console.WriteLine("██████╗ ███████╗██████╗ ██╗     ██╗██╗  ██╗\r\n██╔══██╗██╔════╝██╔══██╗██║     ██║╚██╗██╔╝\r\n██████╔╝█████╗  ██████╔╝██║     ██║ ╚███╔╝ \r\n██╔══██╗██╔══╝  ██╔═══╝ ██║     ██║ ██╔██╗ \r\n██║  ██║███████╗██║     ███████╗██║██╔╝ ██╗");
    Console.WriteLine();
    Console.WriteLine("[0] Settings\n[1] Webhook Message Sender\n[2] Webhook Spammer\n[3] Ping Replixate In DLL Lounge\n[4] File Shit");
    int Option = Convert.ToInt32(Console.ReadLine());
    Console.Clear();

    if (Option == 0)
    {
        Settings();
    }
    if (Option == 1)
    {
        WebhookMessageSender();
    }
    if (Option == 2)
    {
        WebhookSpammer();
    }
    if (Option == 3)
    {
        PingMe();
    }
    if (Option == 4)
    {
        FileStuff();
    }
}

static async void WebhookMessageSender()
{
    Console.WriteLine("--Webhook Message Sender--");
    Console.Write("Enter Webhook URL: ");
    string webhookUrl = Console.ReadLine();
    Console.Write("Enter Message: ");
    string webhookMsg = Console.ReadLine();

        string json = $"{{\"content\":\"{webhookMsg}\"}}";
        using (HttpClient client = new HttpClient())
        {
            HttpContent content = new StringContent(json, Encoding.UTF8, "application/json");
            await client.PostAsync(webhookUrl, content);
        }
    Console.WriteLine("Message successfully sent!\nEnter any key to go back...");
    Console.ReadKey();
    Main();


}

static async void WebhookSpammer()
{
    Console.WriteLine("--Webhook Spammer--");
    Console.Write("Enter Webhook URL: ");
    string webhookUrl = Console.ReadLine();
    Console.Write("Enter Message: ");
    string webhookMsg = Console.ReadLine();
    int i = 1;

    while (i == 1)
    {
        string json = $"{{\"content\":\"{webhookMsg}\"}}";
        using (HttpClient client = new HttpClient())
        {
            HttpContent content = new StringContent(json, Encoding.UTF8, "application/json");
            await client.PostAsync(webhookUrl, content);
            Console.WriteLine("Message Sent!");
        }

    }
}

static async void PingMe()
{
    Console.WriteLine("--Ping Me--");
    Console.WriteLine("[0] Back\n[1] Ping Replixate\n[2] Spam Ping Replixate");
    int pingOption = Convert.ToInt32(Console.ReadLine());
    
    if (pingOption == 0)
    {
        Main();
    }
    if (pingOption == 1)
    {
        string json = $"{{\"content\":\"{"<@1142977735535366206>"}\"}}";
        using (HttpClient client = new HttpClient())
        {
            string webhookUrl = "https://discord.com/api/webhooks/1303467325260828803/0pfjepozWVSmNMR0GG9Dw9yqPWTKagKL2R2JFTrJuoye1gIDEQJ_1buKXYk06XeatUH1";
            HttpContent content = new StringContent(json, Encoding.UTF8, "application/json");
            await client.PostAsync(webhookUrl, content);
            Console.WriteLine("Successfully pinged @replixate!");
            Console.WriteLine("Enter any key to go back...");
            Console.ReadLine();
            Main();
        }
    }
    if (pingOption == 2)
    {
        int i = 1;
        while (i == 1)
        {
            string json = $"{{\"content\":\"{"<@1142977735535366206>"}\"}}";
            using (HttpClient client = new HttpClient())
            {
                string webhookUrl = "https://discord.com/api/webhooks/1303467325260828803/0pfjepozWVSmNMR0GG9Dw9yqPWTKagKL2R2JFTrJuoye1gIDEQJ_1buKXYk06XeatUH1";
                HttpContent content = new StringContent(json, Encoding.UTF8, "application/json");
                await client.PostAsync(webhookUrl, content);
                Console.WriteLine("Pinged @replixate!");
            }
        }
    }
}

static void FileStuff()
{
    Console.WriteLine("--File Shit--");
    Console.WriteLine("[0] Back\n[1] Make a File\n[2] Delete a File");
    int fileOption = Convert.ToInt32(Console.ReadLine());
    Console.Clear();
    if (fileOption == 0)
    {
        Main();
    }
    if (fileOption == 1)
    {
        Console.WriteLine("--Make a File--");
        Console.WriteLine("[0] Back\n[1] Text File\n[2] Exe File");
        int fileType = Convert.ToInt32(Console.ReadLine());
        Console.Clear();
        if (fileType == 0)
        {
            FileStuff();
        }
        if (fileType == 1)
        {
            Console.WriteLine("--Make a Text File--");
            Console.Write("Name of text file: ");
            string fileName = Console.ReadLine();
            Console.Write("Text inside text file: ");
            string fileContents = Console.ReadLine();
            Console.WriteLine("Making file...");
            Thread.Sleep(2000);
            System.IO.File.WriteAllText(fileName + ".txt", fileContents);
            Console.WriteLine("File successfully created, check your app files to find it!\nEnter any key to go back...");
            Console.ReadLine();
            
        }
        if (fileType == 2)
        {
            Console.WriteLine("--Make an Exe File--");
            Console.WriteLine("NOTE: This file will have no function");
            Console.Write("Enter name of exe file: ");
            string exeName = Console.ReadLine();
            Console.WriteLine("Making file...");
            Thread.Sleep(2000);
            System.IO.File.Create(exeName + ".exe");
            Console.WriteLine("File successfully created, check your app files to find it!\nEnter any key to go back...");
            Console.ReadLine();
        }
        Main();
    }
    if (fileOption == 2)
    {
        
        Console.WriteLine("--Delete a File--");
        Console.WriteLine("DISCLAIMER: You can only delete files inside this apps' files\nWhen entering the file name to delete, you must add the file type (example: .txt, .exe, .dll)");
        Console.WriteLine("Enter any key to continue...");
        Console.ReadLine();
        Console.Write("Enter the name of the file to delete: ");
        string deleteName = Console.ReadLine();
        Console.WriteLine("Deleting file...");
        Thread.Sleep(2000);
        Console.WriteLine("File should be deleted, if not, it's because it wasnt in the app files\nEnter any key to go back...");
        Console.ReadLine();
    }
    Main();
}





    static void Settings()
    {
        Console.Clear();
        Console.WriteLine("--Settings--");
        Console.WriteLine("[0] Back\n[1] Text Colour\n[2] Background Colour\n[3] Console App Title");
        int Option = Convert.ToInt32(Console.ReadLine());

        if (Option == 0)
        {
            Main();
        }
        if (Option == 1)
        {
            TextColourOpt();
        }
        if (Option == 2)
        {
            BackgroundColourOpt();
        }
        if (Option == 3)
        {
            ConsoleAppTitle();
        }
    }

    static void TextColourOpt()
    {
        Console.Clear();
        Console.WriteLine("--Text Colour--");
        Console.WriteLine("[0] Back\n[1] Blue\n[2] Cyan\n[3] Green\n[4] Yellow\n[5] Magenta\n[6] Purple\n[7] Red\n[8] White\n[9] Black\n[10] Reset Colour");
        int TextColour = Convert.ToInt32(Console.ReadLine());

        switch (TextColour)
        {
            case 0:
                Settings();
                break;
            case 1:
                Console.ForegroundColor = ConsoleColor.Blue;
                break;
            case 2:
                Console.ForegroundColor = ConsoleColor.Cyan;
                break;
            case 3:
                Console.ForegroundColor = ConsoleColor.Green;
                break;
            case 4:
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                break;
            case 5:
                Console.ForegroundColor = ConsoleColor.Magenta;
                break;
            case 6:
                Console.ForegroundColor = ConsoleColor.DarkMagenta;
                break;
            case 7:
                Console.ForegroundColor = ConsoleColor.DarkRed;
                break;
            case 8:
                Console.ForegroundColor = ConsoleColor.White;
                break;
            case 9:
                Console.ForegroundColor = ConsoleColor.Black;
                break;
            case 10:
                Console.ForegroundColor = ConsoleColor.DarkCyan;
                break;
        }
        Console.Clear();
        TextColourOpt();
    }


    static void BackgroundColourOpt()
    {
        Console.Clear();
        Console.WriteLine("--Background Colour--");
        Console.WriteLine("[0] Back\n[1] Blue\n[2] Cyan\n[3] Green\n[4] Yellow\n[5] Magenta\n[6] Purple\n[7] Red\n[8] White\n[9] Black\n[10] Reset Colour");
        int BackgroundColour = Convert.ToInt32(Console.ReadLine());


        switch (BackgroundColour)
        {
            case 0:
                Settings();
                break;
            case 1:
                Console.BackgroundColor = ConsoleColor.Blue;
                break;
            case 2:
                Console.BackgroundColor = ConsoleColor.Cyan;
                break;
            case 3:
                Console.BackgroundColor = ConsoleColor.Green;
                break;
            case 4:
                Console.BackgroundColor = ConsoleColor.DarkYellow;
                break;
            case 5:
                Console.BackgroundColor = ConsoleColor.Magenta;
                break;
            case 6:
                Console.BackgroundColor = ConsoleColor.DarkMagenta;
                break;
            case 7:
                Console.BackgroundColor = ConsoleColor.DarkRed;
                break;
            case 8:
                Console.BackgroundColor = ConsoleColor.White;
                break;
            case 9:
                Console.BackgroundColor = ConsoleColor.Black;
                break;
            case 10:
                Console.BackgroundColor = ConsoleColor.Black;
                break;
        }
        Console.Clear();
        BackgroundColourOpt();
    }

    static void ConsoleAppTitle()
    {
        Console.Clear();
        Console.WriteLine("--Console App Title--");
        Console.WriteLine("[0] Back\n[1] Custom Name\n[2] Reset Name");
        int AppTitleOption = Convert.ToInt32(Console.ReadLine());
        Console.Clear();
        if (AppTitleOption == 0)
        {

        }
        if (AppTitleOption == 1)
        {

            Console.WriteLine("--Custom Name--");
            Console.Write("Enter Custom Console Name: ");
            string AppName = Console.ReadLine();
            Console.Title = AppName;
            Console.WriteLine("Name successfully changed!\nEnter any key to go back...");
            Console.ReadLine();
        }
        if (AppTitleOption == 2)
        {
            Console.WriteLine("--Reset Name--");
            Console.WriteLine("Enter any key to reset the console name");
            Console.Title = "Replix - MultiTool";
            Console.WriteLine("Name successfully reset!\nEnter any key to go back...");
            Console.ReadLine();

        }
        Settings();
    }






































    static void Arrays()
    {
        //ARRAYS: variables that can contain multiple values

        String[] sigmas = { "Expo", "Dryice", "Silent" }; //How to make an array

        Console.WriteLine(sigmas[0]); //If i remove the [0], it won't work. The [0] indicates what value within the variable is gonna be displayed. As an exampple, in this code, it says [0] so i'm displaying the first value (expo). 
        Console.WriteLine(sigmas[1]);
        Console.WriteLine(sigmas[2]);
        /* sigmas[0] = "ME" 
        * This will update the variables first value into the text "ME"
        */
    }

Console.ReadKey();